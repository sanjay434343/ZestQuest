import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Home as HomeIcon, ChefHat } from 'lucide-react';

export function BottomNav() {
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white shadow-lg z-50">
      <div className="flex justify-around items-center h-16">
        <button
          onClick={() => navigate('/')}
          className={`flex flex-col items-center space-y-1 px-4 py-2 rounded-lg transition-colors ${
            location.pathname === '/' ? 'text-orange-500' : 'text-gray-500'
          }`}
        >
          <HomeIcon className="w-6 h-6" />
          <span className="text-xs">Home</span>
        </button>
        <button
          onClick={() => navigate('/recipe')}
          className={`flex flex-col items-center space-y-1 px-4 py-2 rounded-lg transition-colors ${
            location.pathname === '/recipe' ? 'text-orange-500' : 'text-gray-500'
          }`}
        >
          <ChefHat className="w-6 h-6" />
          <span className="text-xs">Recipe</span>
        </button>
      </div>
    </div>
  );
}