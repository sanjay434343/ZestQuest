import React from 'react';
import { ChefHat } from 'lucide-react';

export function RecipeHeader() {
  return (
    <div className="bg-gradient-to-r from-orange-400 to-red-500 p-6 flex items-center">
      <ChefHat className="w-10 h-10 text-white mr-4" />
      <h1 className="text-2xl font-bold text-white">Your Recipe</h1>
    </div>
  );
}