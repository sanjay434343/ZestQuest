import React, { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';

const loadingMessages = [
  "Preheating the AI oven...",
  "Gathering the ingredients...",
  "Mixing the perfect recipe...",
  "Adding a pinch of magic...",
  "Taste testing...",
  "Almost ready to serve!"
];

export function LoadingState() {
  const [messageIndex, setMessageIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setMessageIndex((prev) => (prev + 1) % loadingMessages.length);
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 max-w-md w-full mx-4 text-center">
        <Loader2 className="w-12 h-12 text-orange-500 animate-spin mx-auto mb-4" />
        <p className="text-lg text-gray-700 animate-pulse">
          {loadingMessages[messageIndex]}
        </p>
      </div>
    </div>
  );
}