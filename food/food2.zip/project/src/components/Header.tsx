import React from 'react';
import { ChefHat } from 'lucide-react';

export function Header() {
  return (
    <div className="text-center mb-12 animate-fade-down">
      <ChefHat className="w-16 h-16 mx-auto text-orange-500 mb-4 hover:scale-110 transition-transform" />
      <h1 className="text-4xl font-bold text-gray-800 mb-2">CulinaryAI</h1>
      <p className="text-gray-600">Transform your ingredients into delicious recipes</p>
    </div>
  );
}