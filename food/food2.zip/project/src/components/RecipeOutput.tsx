import React from 'react';

interface RecipeOutputProps {
  recipe: string;
}

export function RecipeOutput({ recipe }: RecipeOutputProps) {
  const formatRecipe = (text: string) => {
    return text.split('\n').map((line, index) => {
      const boldPattern = /\*\*(.*?)\*\*/g;
      const formattedLine = line.replace(boldPattern, '<strong>$1</strong>');
      
      return (
        <p
          key={index}
          className="mb-4 leading-relaxed"
          dangerouslySetInnerHTML={{ __html: formattedLine }}
        />
      );
    });
  };

  return (
    <div className="prose prose-lg">
      {formatRecipe(recipe)}
    </div>
  );
}