import React from 'react';
import { useLocation } from 'react-router-dom';
import { BackButton } from '../components/BackButton';
import { RecipeHeader } from '../components/RecipeHeader';
import { RecipeOutput } from '../components/RecipeOutput';
import { BottomNav } from '../components/BottomNav';
import { DownloadButton } from '../components/DownloadButton';

export function Recipe() {
  const location = useLocation();
  const { recipe } = location.state || { recipe: '' };

  return (
    <div className="min-h-screen bg-gray-100 py-12 px-4 relative">
      <div className="max-w-4xl mx-auto">
        <BackButton />
        <div className="bg-white rounded-lg shadow-xl h-[calc(100vh-200px)] flex flex-col">
          <RecipeHeader />
          <div className="flex-1 overflow-hidden">
            <div className="h-full overflow-y-auto p-8">
              <RecipeOutput recipe={recipe} />
            </div>
          </div>
        </div>
      </div>
      <DownloadButton recipe={recipe} />
      <BottomNav />
    </div>
  );
}